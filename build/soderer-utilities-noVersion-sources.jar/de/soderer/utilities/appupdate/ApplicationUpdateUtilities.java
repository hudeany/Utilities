package de.soderer.utilities.appupdate;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.Proxy;
import java.net.URI;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.StandardCharsets;
import java.security.cert.CertPathBuilder;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.security.cert.PKIXBuilderParameters;
import java.security.cert.PKIXCertPathBuilderResult;
import java.security.cert.TrustAnchor;
import java.security.cert.X509CertSelector;
import java.security.cert.X509Certificate;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutionException;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.jar.Manifest;

import org.w3c.dom.Document;
import org.w3c.dom.Node;

import de.soderer.json.JsonArray;
import de.soderer.json.JsonNode;
import de.soderer.json.JsonObject;
import de.soderer.json.JsonReader;
import de.soderer.network.HttpUtilities;
import de.soderer.network.NetworkUtilities;
import de.soderer.pac.utilities.ProxyConfiguration;
import de.soderer.utilities.Credentials;
import de.soderer.utilities.IoUtilities;
import de.soderer.utilities.LangResources;
import de.soderer.utilities.SystemUtilities;
import de.soderer.utilities.Tuple;
import de.soderer.utilities.UserError;
import de.soderer.utilities.UserError.Reason;
import de.soderer.utilities.Utilities;
import de.soderer.utilities.Version;
import de.soderer.utilities.worker.FileCopyWorker;
import de.soderer.utilities.worker.FileDownloadWorker;
import de.soderer.utilities.worker.WorkerParentSimple;
import de.soderer.utilities.xml.XmlUtilities;

/**
 * versionIndexFileLocation
 * 	may include placeholders:<br />
 * 		&lt;system> : replaced by "windows" or "linux"<br />
 *  	&lt;bitmode> : replaced by "32" or "64"<br />
 * 		&lt;username> : interactive username dialog<br />
 * 		&lt;password> : interactive password dialog<br />
 * 		&lt;time_seconds> : current timestamp in seconds (used by sourceforge.net)
 */
public class ApplicationUpdateUtilities {
	public static boolean DEBUGGING_UPDATER = false;
	public static boolean DEBUGGING_RESTARTER = false;

	public static final int EOF = -1;

	public static boolean executeUpdate(
			final ApplicationUpdateParent updateParent,
			final String versionIndexFileLocation,
			final ProxyConfiguration proxyConfiguration,
			final String applicationName,
			final Version applicationVersion,
			final String trustedCaCertificateFileNames,
			final String username,
			final char[] password,
			final List<String> appParameters,
			final boolean restartAfterUpdate,
			final boolean allowUnsafeUpdates) throws Exception {
		try {
			if (Utilities.isEmpty(versionIndexFileLocation)) {
				throw new Exception("Invalid version index location");
			}

			final Tuple<Version, String> newVersionAvailable = checkForNewVersionAvailable(versionIndexFileLocation, proxyConfiguration, applicationName, applicationVersion);
			if ((newVersionAvailable != null && username != null)
					|| askForUpdate(updateParent, newVersionAvailable != null ? newVersionAvailable.getFirst() : null)) {
				final List<String> jvmParameters = SystemUtilities.getCurrentJvmParameters();
				updateApplication(updateParent, newVersionAvailable != null ? newVersionAvailable.getSecond() : null, proxyConfiguration, trustedCaCertificateFileNames, username, password, jvmParameters, appParameters, restartAfterUpdate, allowUnsafeUpdates);
			}
			return true;
		} catch (final Exception e) {
			if (updateParent != null) {
				showUpdateError(updateParent, LangResources.get("updateErrorVersionCheck", e.getMessage()));
				return false;
			} else {
				throw e;
			}
		}
	}

	public static Tuple<Version, String> checkForNewVersionAvailable(final String versionIndexFileLocation, final ProxyConfiguration proxyConfiguration, final String applicationName, final Version applicationVersion) throws Exception {
		try {
			if (Utilities.isEmpty(versionIndexFileLocation)) {
				throw new Exception("Invalid version index location");
			} else if (!NetworkUtilities.checkForNetworkConnection()) {
				throw new Exception("error.missingNetworkConnection");
			}

			Version availableVersion = null;
			String updateFileLocation = null;
			if (versionIndexFileLocation.toLowerCase().startsWith("http://") || versionIndexFileLocation.toLowerCase().startsWith("https://")) {
				if (!NetworkUtilities.ping(versionIndexFileLocation, proxyConfiguration == null ? Proxy.NO_PROXY : proxyConfiguration.getProxy(versionIndexFileLocation))) {
					if (proxyConfiguration == null) {
						throw new Exception("error.missingInternetConnection: " + versionIndexFileLocation);
					} else {
						throw new Exception("error.missingInternetConnection (using ProxyConfiguration " + proxyConfiguration.getProxyConfigurationType() + "): " + versionIndexFileLocation);
					}
				}
				final String hostname = NetworkUtilities.getHostnameFromRequestString(versionIndexFileLocation);
				if ("soderer.de".equalsIgnoreCase(hostname)) {
					if (versionIndexFileLocation.toLowerCase().contains("json")) {
						final URLConnection urlConnection = URI.create(versionIndexFileLocation).toURL().openConnection(proxyConfiguration == null ? Proxy.NO_PROXY : proxyConfiguration.getProxy(versionIndexFileLocation));
						urlConnection.setRequestProperty("Pragma", "no-cache");
						try (JsonReader jsonReader = new JsonReader(new BufferedInputStream(urlConnection.getInputStream()))) {
							final JsonNode jsonNode = jsonReader.read();
							if (!jsonNode.isJsonObject()) {
								throw new Exception("Invalid version index found at location '" + versionIndexFileLocation + "'");
							} else {
								final JsonObject jsonObject = (JsonObject) jsonNode;
								final JsonObject applicationJsonObject = (JsonObject) jsonObject.get(applicationName);
								if (applicationJsonObject == null) {
									throw new Exception("Version index not found at location '" + versionIndexFileLocation + "'");
								} else {
									try {
										availableVersion = new Version((String) applicationJsonObject.getSimpleValue("version"));
										updateFileLocation = (String) applicationJsonObject.getSimpleValue("downloadUrl");
									} catch (final Exception e) {
										throw new Exception("Invalid application version entry at location '" + versionIndexFileLocation + "'", e);
									}
								}
							}
						} catch (final Exception e) {
							throw new Exception("Invalid version index found at location '" + versionIndexFileLocation + "':\n" + e.getMessage(), e);
						}
					} else {
						Document versionsDocument = null;
						if (versionIndexFileLocation.toLowerCase().startsWith("http")) {
							versionsDocument = XmlUtilities.downloadAndParseXmlFile(versionIndexFileLocation, null);
						} else if (new File(versionIndexFileLocation).exists()) {
							versionsDocument = XmlUtilities.parseXmlFile(new File(versionIndexFileLocation));
						}

						if (versionsDocument == null) {
							throw new Exception("Version index not found at location '" + versionIndexFileLocation + "'");
						}

						final Node startFileNameNode = XmlUtilities.getSingleXPathNode(versionsDocument, "ApplicationVersions/" + applicationName);
						if (startFileNameNode == null) {
							throw new Exception("error.cannotFindUpdateVersionData");
						}

						final Node versionNode = startFileNameNode.getAttributes().getNamedItem("version");
						if (versionNode != null && Utilities.isNotBlank(versionNode.getNodeValue())) {
							availableVersion = new Version(versionNode.getNodeValue());
						}

						if (startFileNameNode.getFirstChild() != null && Utilities.isNotBlank(startFileNameNode.getFirstChild().getNodeValue())) {
							updateFileLocation = startFileNameNode.getFirstChild().getNodeValue();
						}
					}
				} else if ("api.github.com".equalsIgnoreCase(hostname)) {
					final URLConnection urlConnection = URI.create(versionIndexFileLocation).toURL().openConnection(proxyConfiguration == null ? Proxy.NO_PROXY : proxyConfiguration.getProxy(versionIndexFileLocation));
					urlConnection.setRequestProperty("Pragma", "no-cache");
					try (JsonReader jsonReader = new JsonReader(new BufferedInputStream(urlConnection.getInputStream()))) {
						final JsonNode jsonNode = jsonReader.read();
						if (!jsonNode.isJsonObject()) {
							throw new Exception("Invalid github release data found at location '" + versionIndexFileLocation + "'");
						} else {
							final JsonObject jsonObject = (JsonObject) jsonNode;
							final String githubApplicationNameAndVersion = (String) jsonObject.getSimpleValue("name");
							if (!githubApplicationNameAndVersion.trim().startsWith(applicationName)) {
								throw new Exception("Invalid github release data found for application '" + applicationName + "' was '" + githubApplicationNameAndVersion + "'");
							}
							availableVersion = new Version((String) jsonObject.getSimpleValue("tag_name"));

							final JsonArray assets = (JsonArray) jsonObject.get("assets");
							if (assets == null) {
								throw new Exception("Github release for application '" + applicationName + "' has no assets");
							}
							String jarAssetDownloadUrl = null;
							for (int assetIndex = 0; jarAssetDownloadUrl == null; assetIndex++) {
								final JsonObject assetObject;
								try {
									assetObject = (JsonObject) assets.get(assetIndex);
								} catch (@SuppressWarnings("unused") final IndexOutOfBoundsException indexOutOfBoundsException) {
									// Reached the end of the assets list without finding a ".jar" asset
									break;
								}
								final String assetName = (String) assetObject.getSimpleValue("name");
								if (isApplicationJarAssetName(assetName)) {
									jarAssetDownloadUrl = (String) assetObject.getSimpleValue("browser_download_url");
								}
							}
							if (jarAssetDownloadUrl == null) {
								throw new Exception("Github release for application '" + applicationName + "' has no '.jar' asset");
							}
							updateFileLocation = jarAssetDownloadUrl;
						}
					} catch (final Exception e) {
						throw new Exception("Invalid version index found at location '" + versionIndexFileLocation + "':\n" + e.getMessage(), e);
					}
				} else {
					final URLConnection urlConnection = URI.create(versionIndexFileLocation).toURL().openConnection(proxyConfiguration == null ? Proxy.NO_PROXY : proxyConfiguration.getProxy(versionIndexFileLocation));
					urlConnection.setRequestProperty("Pragma", "no-cache");
					try (JsonReader jsonReader = new JsonReader(new BufferedInputStream(urlConnection.getInputStream()))) {
						final JsonNode jsonNode = jsonReader.read();
						if (!jsonNode.isJsonObject()) {
							throw new Exception("Invalid version index found at location '" + versionIndexFileLocation + "'");
						} else {
							final JsonObject jsonObject = (JsonObject) jsonNode;
							final JsonObject applicationJsonObject = (JsonObject) jsonObject.get(applicationName);
							if (applicationJsonObject == null) {
								throw new Exception("Version index not found at location '" + versionIndexFileLocation + "'");
							} else {
								try {
									availableVersion = new Version((String) applicationJsonObject.getSimpleValue("version"));
									updateFileLocation = (String) applicationJsonObject.getSimpleValue("downloadUrl");
								} catch (final Exception e) {
									throw new Exception("Invalid application version entry at location '" + versionIndexFileLocation + "'", e);
								}
							}
						}
					} catch (final Exception e) {
						throw new Exception("Invalid version index found at location '" + versionIndexFileLocation + "':\n" + e.getMessage(), e);
					}
				}
			} else if (versionIndexFileLocation.toLowerCase().startsWith("file://") && versionIndexFileLocation.toLowerCase().endsWith(".json")) {
				final URL versionIndexFileURL = URI.create(versionIndexFileLocation).toURL();
				try (JsonReader jsonReader = new JsonReader(versionIndexFileURL.openStream())) {
					final JsonNode jsonNode = jsonReader.read();
					if (!jsonNode.isJsonObject()) {
						throw new Exception("Invalid version index found at location '" + versionIndexFileLocation + "'");
					} else {
						final JsonObject jsonObject = (JsonObject) jsonNode;
						final JsonObject applicationJsonObject = (JsonObject) jsonObject.get(applicationName);
						if (applicationJsonObject == null) {
							throw new Exception("Version index not found at location '" + versionIndexFileLocation + "'");
						} else {
							try {
								availableVersion = new Version((String) applicationJsonObject.getSimpleValue("version"));
								updateFileLocation = (String) applicationJsonObject.getSimpleValue("downloadUrl");
							} catch (final Exception e) {
								throw new Exception("Invalid application version entry at location '" + versionIndexFileLocation + "'", e);
							}
						}
					}
				}
			}

			if (applicationVersion.compareTo(availableVersion) < 0 && updateFileLocation != null && updateFileLocation.trim().length() > 0) {
				updateFileLocation = replacePlaceholders(updateFileLocation);
				return new Tuple<>(availableVersion, updateFileLocation);
			} else {
				updateFileLocation = null;
				return null;
			}
		} catch (final Exception e) {
			throw e;
		}
	}

	private static boolean askForUpdate(final ApplicationUpdateParent updateParent, final Version availableNewVersion) {
		if (updateParent != null) {
			try {
				return updateParent.askForUpdate(availableNewVersion);
			} catch (final Exception e) {
				updateParent.showUpdateError("Update error:\n" + e.getMessage());
				return false;
			}
		} else {
			return false;
		}
	}

	public static void restart(final String jarFilePath, final List<String> jvmParameters, final List<String> appParameters) {
		try {
			final InputStream updaterInputStream = ApplicationUpdateUtilities.class.getClassLoader().getResourceAsStream("Restarter.jar");
			if (updaterInputStream == null) {
				throw new Exception("Restarter binary not available");
			}

			final File restarterFile = new File(System.getProperty("java.io.tmpdir"), "Restarter_" + new File(jarFilePath).getName() +".jar");
			if (restarterFile.exists() && !restarterFile.delete()) {
				throw new Exception("Cannot remove leftover restarter file '" + restarterFile.getAbsolutePath() + "', it may still be in use");
			}
			try (FileOutputStream updaterOut = new FileOutputStream(restarterFile)) {
				IoUtilities.copy(updaterInputStream, updaterOut);
			}

			String javaBinPath = SystemUtilities.getJavaBinPath();
			if (Utilities.isBlank(javaBinPath)) {
				if (SystemUtilities.isWindowsSystem()) {
					javaBinPath = "java.exe";
				} else {
					javaBinPath = "java";
				}
			}

			final List<String> restarterCommandList = new ArrayList<>();
			restarterCommandList.add(javaBinPath);
			restarterCommandList.add("-jar");
			restarterCommandList.add(restarterFile.getAbsolutePath());

			if (DEBUGGING_RESTARTER) {
				restarterCommandList.add("-log");
			}

			restarterCommandList.add(jarFilePath);

			if (jvmParameters != null && jvmParameters.size() > 0) {
				restarterCommandList.add("-jvmParameter");
				for (final String token : jvmParameters) {
					restarterCommandList.add(token);
				}
			}

			if (appParameters != null && appParameters.size() > 0) {
				restarterCommandList.add("-appParameter");
				for (final String token : appParameters) {
					restarterCommandList.add(token);
				}
			}

			final String[] restarterCommand = restarterCommandList.toArray(new String[0]);

			final ProcessBuilder restarterProcessBuilder = new ProcessBuilder(restarterCommand);
			restarterProcessBuilder.redirectOutput(ProcessBuilder.Redirect.DISCARD);
			restarterProcessBuilder.redirectError(ProcessBuilder.Redirect.DISCARD);

			restarterProcessBuilder.start();

			Runtime.getRuntime().exit(0);
		} catch (final Exception e) {
			System.err.println("Update error while updating to new version:\n" + e.getMessage());
			e.printStackTrace();
			return;
		}
	}

	private static boolean updateApplication(final ApplicationUpdateParent updateParent, final String updateFileLocation, final ProxyConfiguration proxyConfiguration, final String trustedCaCertificateFileNames, final String username, final char[] password, final List<String> jvmParameters, final List<String> appParameters, final boolean restartAfterUpdate, final boolean allowUnsafeUpdates) {
		try {
			if (Utilities.isBlank(updateFileLocation)) {
				throw new Exception("Mandatory updateFileLocation is empty");
			}

			String jarFilePath = SystemUtilities.getCurrentlyRunningJarFilePath();

			if (jarFilePath == null) {
				try {
					final String currentJarUrlPath = updateParent.getClass().getResource(updateParent.getClass().getSimpleName() + ".class").toString();
					// The class resource URL is percent-encoded (e.g. "%20" for spaces in the path),
					// so it must be decoded via URI/File instead of just stripping "jar:file:" as plain text
					final String jarFileUriPart = currentJarUrlPath.substring("jar:".length(), currentJarUrlPath.lastIndexOf("!"));
					jarFilePath = new File(URI.create(jarFileUriPart)).getAbsolutePath();
				} catch (@SuppressWarnings("unused") final Exception e) {
					jarFilePath = null;
				}
			}

			jarFilePath = Utilities.replaceUsersHome(jarFilePath);

			if (jarFilePath == null || !new File(jarFilePath).exists()) {
				throw new Exception("Current running jar file was not found");
			}

			final File downloadTempFile = new File(new File(jarFilePath).getParent() + File.separator + "temp_" + new File(jarFilePath).getName());

			final boolean downloadSuccess = getNewApplicationVersionFile(updateParent, username, password, updateFileLocation, proxyConfiguration, downloadTempFile);
			if (downloadSuccess) {
				if (Utilities.isNotEmpty(trustedCaCertificateFileNames)) {
					final ClassLoader applicationClassLoader = updateParent.getClass().getClassLoader();
					if (applicationClassLoader == null) {
						showUpdateError(updateParent, "Update error:\nApplications classloader is not readable");
						return false;
					}

					final Collection<Certificate> trustedCertificates = new ArrayList<>();
					for (final String trustedCaCertificateFileName : Utilities.splitAndTrimList(trustedCaCertificateFileNames)) {
						try (InputStream trustedUpdateCertificatesStream = applicationClassLoader.getResourceAsStream(trustedCaCertificateFileName)) {
							if (trustedUpdateCertificatesStream != null) {
								for (final Certificate trustedCaCertificate : CertificateFactory.getInstance("X.509").generateCertificates(new BufferedInputStream(trustedUpdateCertificatesStream))) {
									trustedCertificates.add(trustedCaCertificate);
								}
							}
						} catch (final Exception e) {
							showUpdateError(updateParent, "Update error:\nTrusted CA certificate '" + trustedCaCertificateFileName + "' is not readable: " + e.getMessage());
							return false;
						}
					}

					if (trustedCertificates.size() == 0) {
						showUpdateError(updateParent, "Update error:\nTrusted CA certificate is missing");
						return false;
					} else if (!verifyJarSignature(downloadTempFile, trustedCertificates)) {
						showUpdateError(updateParent, "Update error:\nSignature of updatefile is invalid");
						return false;
					}
				} else if (!allowUnsafeUpdates) {
					showUpdateError(updateParent, "Update error:\nTrusted CA certificate file name is missing");
					return false;
				}

				final String[] updaterCommand;
				if (updateParent != null) {
					try (final InputStream updaterInputStream = ApplicationUpdateUtilities.class.getClassLoader().getResourceAsStream("Updater.jar")) {
						if (updaterInputStream != null) {
							final File updaterFile = new File(new File(jarFilePath).getParent(), "Updater_" + new File(jarFilePath).getName() + ".jar");
							if (updaterFile.exists() && !updaterFile.delete()) {
								throw new Exception("Cannot remove leftover updater file '" + updaterFile.getAbsolutePath() + "' from a previous update, it may still be in use");
							}
							try (FileOutputStream updaterOut = new FileOutputStream(updaterFile)) {
								IoUtilities.copy(updaterInputStream, updaterOut);
							}

							String javaBinPath = SystemUtilities.getJavaBinPath();
							if (Utilities.isBlank(javaBinPath)) {
								if (SystemUtilities.isWindowsSystem()) {
									javaBinPath = "java.exe";
								} else {
									javaBinPath = "java";
								}
							}

							final List<String> commandParts = new ArrayList<>(List.of(javaBinPath, "-jar", updaterFile.getAbsolutePath()));
							if (DEBUGGING_UPDATER) {
								commandParts.add("-log");
								commandParts.add("-stepwait");
							}
							commandParts.add(jarFilePath);
							commandParts.add(downloadTempFile.getAbsolutePath());
							if (!restartAfterUpdate) {
								commandParts.add("-norestart");
							}

							if (jvmParameters != null && jvmParameters.size() > 0) {
								commandParts.add("-jvmParameter");
								for (final String token : jvmParameters) {
									commandParts.add(token);
								}
							}

							if (appParameters != null && appParameters.size() > 0) {
								commandParts.add("-appParameter");
								for (final String token : appParameters) {
									commandParts.add(token);
								}
							}

							updaterCommand = commandParts.toArray(new String[0]);
						} else {
							updaterCommand = createUpdateBatchFile(jarFilePath, downloadTempFile, restartAfterUpdate, null);
						}
					}
				} else {
					updaterCommand = createUpdateBatchFile(jarFilePath, downloadTempFile, restartAfterUpdate, null);
				}

				if (updateParent != null) {
					updateParent.showUpdateDone(null, null, 0, null);
				}

				if (updaterCommand != null) {
					final ProcessBuilder restarterProcessBuilder = new ProcessBuilder(updaterCommand);
					restarterProcessBuilder.redirectOutput(ProcessBuilder.Redirect.DISCARD);
					restarterProcessBuilder.redirectError(ProcessBuilder.Redirect.DISCARD);
					restarterProcessBuilder.start();

					Runtime.getRuntime().exit(0);
				}

				return true;
			} else {
				return false;
			}
		} catch (final Exception e) {
			System.err.println("Update error while updating to new version:\n" + e.getMessage());
			e.printStackTrace();

			showUpdateError(updateParent, "Update error while updating to new version:\n" + e.getMessage());
			return false;
		}
	}

	public static boolean updateNonInteractiveApplication(final Class<? extends ApplicationUpdateParent> applicationClass, final String updateFileLocation, final ProxyConfiguration proxyConfiguration, final String trustedCaCertificateFileNames, final String username, final char[] password, final List<String> jvmParameters, final List<String> appParameters, final boolean restartAfterUpdate) throws Exception {
		try {
			if (Utilities.isBlank(updateFileLocation)) {
				throw new Exception("Mandatory updateFileLocation is empty");
			}

			String jarFilePath = SystemUtilities.getCurrentlyRunningJarFilePath();

			if (jarFilePath == null) {
				try {
					final String currentJarUrlPath = applicationClass.getResource(applicationClass.getSimpleName() + ".class").toString();
					// The class resource URL is percent-encoded (e.g. "%20" for spaces in the path),
					// so it must be decoded via URI/File instead of just stripping "jar:file:" as plain text
					final String jarFileUriPart = currentJarUrlPath.substring("jar:".length(), currentJarUrlPath.lastIndexOf("!"));
					jarFilePath = new File(URI.create(jarFileUriPart)).getAbsolutePath();
				} catch (@SuppressWarnings("unused") final Exception e) {
					jarFilePath = null;
				}
			}

			jarFilePath = Utilities.replaceUsersHome(jarFilePath);

			if (jarFilePath == null || !new File(jarFilePath).exists()) {
				throw new Exception("Current running jar file was not found");
			}

			final File downloadTempFile = new File(new File(jarFilePath).getParent() + File.separator + "temp_" + new File(jarFilePath).getName());

			final boolean downloadSuccess = getNewNonInteractiveApplicationVersionFile(username, password, updateFileLocation, proxyConfiguration, downloadTempFile);
			if (downloadSuccess) {
				if (Utilities.isNotEmpty(trustedCaCertificateFileNames)) {
					final ClassLoader applicationClassLoader = applicationClass.getClassLoader();
					if (applicationClassLoader == null) {
						throw new Exception("Update error:\nApplications classloader is not readable");
					}

					final Collection<Certificate> trustedCertificates = new ArrayList<>();
					for (final String trustedCaCertificateFileName : Utilities.splitAndTrimList(trustedCaCertificateFileNames)) {
						try (InputStream trustedUpdateCertificatesStream = applicationClassLoader.getResourceAsStream(trustedCaCertificateFileName)) {
							if (trustedUpdateCertificatesStream != null) {
								for (final Certificate trustedCaCertificate : CertificateFactory.getInstance("X.509").generateCertificates(new BufferedInputStream(trustedUpdateCertificatesStream))) {
									trustedCertificates.add(trustedCaCertificate);
								}
							}
						} catch (final Exception e) {
							throw new Exception("Update error:\nTrusted CA certificate '" + trustedCaCertificateFileName + "' is not readable: " + e.getMessage());
						}
					}

					if (trustedCertificates.size() == 0) {
						throw new Exception("Update error:\nTrusted CA certificate is missing");
					} else if (!verifyJarSignature(downloadTempFile, trustedCertificates)) {
						throw new Exception("Update error:\nSignature of updatefile is invalid");
					}
				} else {
					throw new Exception("Update error:\nTrusted CA certificate file name is missing");
				}

				final String[] updaterCommand;
				final InputStream updaterInputStream = ApplicationUpdateUtilities.class.getClassLoader().getResourceAsStream("Updater.jar");
				if (updaterInputStream != null) {
					final File updaterFile = new File(new File(jarFilePath).getParent(), "Updater_" + new File(jarFilePath).getName() +".jar");
					if (updaterFile.exists() && !updaterFile.delete()) {
						throw new Exception("Cannot remove leftover updater file '" + updaterFile.getAbsolutePath() + "' from a previous update, it may still be in use");
					}
					try (FileOutputStream updaterOut = new FileOutputStream(updaterFile)) {
						IoUtilities.copy(updaterInputStream, updaterOut);
					}

					String javaBinPath = SystemUtilities.getJavaBinPath();
					if (Utilities.isBlank(javaBinPath)) {
						if (SystemUtilities.isWindowsSystem()) {
							javaBinPath = "java.exe";
						} else {
							javaBinPath = "java";
						}
					}

					final List<String> commandParts = new ArrayList<>(List.of(javaBinPath, "-jar", updaterFile.getAbsolutePath()));
					if (DEBUGGING_UPDATER) {
						commandParts.add("-log");
						commandParts.add("-stepwait");
					}
					commandParts.add(jarFilePath);
					commandParts.add(downloadTempFile.getAbsolutePath());
					if (!restartAfterUpdate) {
						commandParts.add("-norestart");
					}

					if (jvmParameters != null && jvmParameters.size() > 0) {
						commandParts.add("-jvmParameter");
						for (final String token : jvmParameters) {
							commandParts.add(token);
						}
					}

					if (appParameters != null && appParameters.size() > 0) {
						commandParts.add("-appParameter");
						for (final String token : appParameters) {
							commandParts.add(token);
						}
					}

					updaterCommand = commandParts.toArray(new String[0]);
				} else {
					updaterCommand = createUpdateBatchFile(jarFilePath, downloadTempFile, restartAfterUpdate, null);
				}

				if (updaterCommand != null) {
					Runtime.getRuntime().exec(updaterCommand, null, null);
					Runtime.getRuntime().exit(0);
				}

				return true;
			} else {
				return false;
			}
		} catch (final Exception e) {
			throw new Exception("Update error while updating to new version:\n" + e.getMessage(), e);
		}
	}

	private static boolean getNewApplicationVersionFile(final ApplicationUpdateParent updateParent, final String username, final char[] password, final String updateFileLocation, final ProxyConfiguration proxyConfiguration, final File downloadTempFile) throws Exception {
		if (updateFileLocation.toLowerCase().startsWith("http://") || updateFileLocation.toLowerCase().startsWith("https://")) {
			// Download file
			boolean retryDownload = true;
			boolean firstRequest = true;
			while (retryDownload) {
				String downloadUrlWithCredentials = updateFileLocation;

				// Only use preconfigured credentials in first try only
				if (firstRequest) {
					if (username != null) {
						downloadUrlWithCredentials = downloadUrlWithCredentials.replace("<username>", HttpUtilities.urlEncode(username, StandardCharsets.UTF_8));
					}
					if (password != null) {
						downloadUrlWithCredentials = downloadUrlWithCredentials.replace("<password>", HttpUtilities.urlEncode(new String(password), StandardCharsets.UTF_8));
					}
				}

				if (downloadUrlWithCredentials.contains("<username>") && downloadUrlWithCredentials.contains("<password>")) {
					if (updateParent != null) {
						final Credentials credentials = updateParent.aquireCredentials(LangResources.get("enterDownloadCredentials"), true, true, firstRequest);
						if (credentials == null) {
							updateParent.showUpdateError(LangResources.get("canceledByUser"));
							return false;
						} else if (Utilities.isEmpty(credentials.getUsername()) || Utilities.isEmpty(credentials.getPassword())) {
							updateParent.showUpdateError(LangResources.get("usernameAndPasswordRequired"));
							return false;
						} else {
							downloadUrlWithCredentials = downloadUrlWithCredentials.replace("<username>", HttpUtilities.urlEncode(credentials.getUsername(), StandardCharsets.UTF_8));
							downloadUrlWithCredentials = downloadUrlWithCredentials.replace("<password>", HttpUtilities.urlEncode(new String(credentials.getPassword()), StandardCharsets.UTF_8));
						}
					} else {
						showUpdateError(updateParent, LangResources.get("usernameAndPasswordRequired"));
						return false;
					}
				} else if (downloadUrlWithCredentials.contains("<username>")) {
					if (updateParent != null) {
						final Credentials credentials = updateParent.aquireCredentials(LangResources.get("enterDownloadUsername"), true, false, firstRequest);
						if (credentials == null) {
							updateParent.showUpdateError(LangResources.get("canceledByUser"));
							return false;
						} else if (Utilities.isEmpty(credentials.getUsername())) {
							updateParent.showUpdateError(LangResources.get("usernameRequired"));
							return false;
						} else {
							downloadUrlWithCredentials = downloadUrlWithCredentials.replace("<username>", HttpUtilities.urlEncode(credentials.getUsername(), StandardCharsets.UTF_8));
						}
					} else {
						showUpdateError(updateParent, LangResources.get("usernameRequired"));
						return false;
					}
				} else if (downloadUrlWithCredentials.contains("<password>")) {
					if (updateParent != null) {
						final Credentials credentials = updateParent.aquireCredentials(LangResources.get("enterDownloadPassword"), false, true, firstRequest);
						if (credentials == null) {
							updateParent.showUpdateError(LangResources.get("canceledByUser"));
							return false;
						} else if (Utilities.isEmpty(credentials.getPassword())) {
							updateParent.showUpdateError(LangResources.get("passwordRequired"));
							return false;
						} else {
							downloadUrlWithCredentials = downloadUrlWithCredentials.replace("<password>", HttpUtilities.urlEncode(new String(credentials.getPassword()), StandardCharsets.UTF_8));
						}
					} else {
						showUpdateError(updateParent, LangResources.get("passwordRequired"));
						return false;
					}
				}

				retryDownload = false;
				try {
					if (downloadTempFile.exists()) {
						downloadTempFile.delete();
					}
					final boolean success = downloadUpdateFile(updateParent, downloadTempFile, downloadUrlWithCredentials, proxyConfiguration);
					if (!success) {
						// download stopped by user
						updateParent.showUpdateError(LangResources.get("canceledByUser"));
						return false;
					}
				} catch (final UserError e) {
					if (updateParent != null) {
						updateParent.showUpdateError("Update error:\n" + e.getMessage());

						if (e.getReason() == Reason.UnauthenticatedOrUnauthorized) {
							if (updateFileLocation.contains("<username>") || updateFileLocation.contains("<password>")) {
								retryDownload = true;
							} else {
								System.err.println("Update error:\nAuthentication error");
								return false;
							}
						} else {
							return false;
						}
					} else {
						System.err.println("Update error while downloading new version:\n" + e.getMessage());
						return false;
					}
				} catch (final Exception e) {
					if (e instanceof ExecutionException && e.getCause() instanceof UserError) {
						if (updateParent != null) {
							updateParent.showUpdateError("Update error:\n" + e.getCause().getMessage());

							if (((UserError) e.getCause()).getReason() == Reason.UnauthenticatedOrUnauthorized) {
								if (updateFileLocation.contains("<username>") || updateFileLocation.contains("<password>")) {
									retryDownload = true;
								} else {
									System.err.println("Update error:\nAuthentication error");
									return false;
								}
							} else {
								return false;
							}
						} else {
							System.err.println("Update error while downloading new version:\n" + e.getCause().getMessage());
							return false;
						}
					} else {
						showUpdateError(updateParent, "Update error:\n" + e.getMessage());
						return false;
					}
				}

				firstRequest = false;
			}
		} else if (updateFileLocation.toLowerCase().startsWith("file://")) {
			if (downloadTempFile.exists()) {
				downloadTempFile.delete();
			}
			final boolean success = copyUpdateFile(updateParent, downloadTempFile, updateFileLocation);
			if (!success) {
				// download stopped by user
				updateParent.showUpdateError(LangResources.get("canceledByUser"));
				return false;
			}
		} else {
			// Copy file
			if (downloadTempFile.exists()) {
				downloadTempFile.delete();
			}
			final boolean success = copyUpdateFile(updateParent, downloadTempFile, updateFileLocation);
			if (!success) {
				// download stopped by user
				updateParent.showUpdateError(LangResources.get("canceledByUser"));
				return false;
			}
		}

		return downloadTempFile.exists();
	}

	private static boolean getNewNonInteractiveApplicationVersionFile(final String username, final char[] password, final String updateFileLocation, final ProxyConfiguration proxyConfiguration, final File downloadTempFile) throws Exception {
		if (updateFileLocation.toLowerCase().startsWith("http")) {
			// Download file
			String downloadUrlWithCredentials = updateFileLocation;

			if (username != null) {
				downloadUrlWithCredentials = downloadUrlWithCredentials.replace("<username>", HttpUtilities.urlEncode(username, StandardCharsets.UTF_8));
			}
			if (password != null) {
				downloadUrlWithCredentials = downloadUrlWithCredentials.replace("<password>", HttpUtilities.urlEncode(new String(password), StandardCharsets.UTF_8));
			}

			if (downloadUrlWithCredentials.contains("<username>") && downloadUrlWithCredentials.contains("<password>")) {
				throw new Exception("Requiring username and password for update");
			} else if (downloadUrlWithCredentials.contains("<username>")) {
				throw new Exception("Requiring username for update");
			} else if (downloadUrlWithCredentials.contains("<password>")) {
				throw new Exception("Requiring password for update");
			}

			try {
				if (downloadTempFile.exists()) {
					downloadTempFile.delete();
				}
				final boolean success = downloadUpdateFile(null, downloadTempFile, downloadUrlWithCredentials, proxyConfiguration);
				if (!success) {
					throw new Exception("Download failed");
				}
			} catch (final UserError e) {
				throw new Exception("Update error while downloading new version:\n" + e.getMessage(), e);
			} catch (final Exception e) {
				if (e instanceof ExecutionException && e.getCause() instanceof UserError) {
					throw new Exception("Update error while downloading new version:\n" + e.getCause().getMessage(), e);
				} else {
					throw new Exception("Update error:\n" + e.getMessage(), e);
				}
			}
		} else if (updateFileLocation.toLowerCase().startsWith("file://")) {
			if (downloadTempFile.exists()) {
				downloadTempFile.delete();
			}
			final boolean success = copyUpdateFile(null, downloadTempFile, updateFileLocation);
			if (!success) {
				throw new Exception("Download failed");
			}
		} else {
			// Copy file
			if (downloadTempFile.exists()) {
				downloadTempFile.delete();
			}
			final boolean success = copyUpdateFile(null, downloadTempFile, updateFileLocation);
			if (!success) {
				throw new Exception("Download failed");
			}
		}

		return downloadTempFile.exists();
	}

	private static String[] createUpdateBatchFile(final String jarFilePath, final File downloadTempFile, final boolean restartApplicationAfterUpdate, final String appParameter) throws Exception {
		String javaBinPath = SystemUtilities.getJavaBinPath();
		if (Utilities.isBlank(javaBinPath)) {
			if (SystemUtilities.isWindowsSystem()) {
				javaBinPath = "java.exe";
			} else {
				javaBinPath = "java";
			}
		}
		if (SystemUtilities.isWindowsSystem()) {
			final File batchFile = new File(new File(jarFilePath).getParent() + File.separator + "batchUpdate_" + new File(jarFilePath).getName() + ".cmd");
			writeFile(batchFile,
					"@echo off\r\n"
							+ "del \"" + jarFilePath + "\"\r\n"
							+ "if exist \"" + jarFilePath + "\" (\r\n"
							+ "ping -n 3 127.0.0.1 >nul\r\n"
							+ "del \"" + jarFilePath + "\"\r\n"
							+ "if exist \"" + jarFilePath + "\" (\r\n"
							+ "ping -n 3 127.0.0.1 >nul\r\n"
							+ "del \"" + jarFilePath + "\"\r\n"
							+ "if exist \"" + jarFilePath + "\" (\r\n"
							+ "ping -n 3 127.0.0.1 >nul\r\n"
							+ "del \"" + jarFilePath + "\"\r\n"
							+ ")\r\n"
							+ ")\r\n"
							+ ")\r\n"
							+ "ren \"" + downloadTempFile.getAbsolutePath() + "\" \"" + new File(jarFilePath).getName() + "\"\r\n"
							+ "if not exist \"" + downloadTempFile.getAbsolutePath() + "\" (\r\n"
							+ (restartApplicationAfterUpdate ? "\"" + javaBinPath + "\" -jar \"" + jarFilePath + "\"" + (appParameter != null ? " " + appParameter : "") + "\r\n" : "")
							+ "del \"" + batchFile.getAbsolutePath() + "\"\r\n"
							+ ")\r\n");

			return new String[]{ "cmd", "/c", "start", "/B", batchFile.getAbsolutePath() };
		} else if (SystemUtilities.isLinuxSystem()) {
			final File batchFile = new File(new File(jarFilePath).getParent() + File.separator + "batchUpdate_" + new File(jarFilePath).getName() + ".sh");
			writeFile(batchFile,
					"#!/bin/bash\n"
							+ "rm \"" + jarFilePath + "\"\n"
							+ "if [ -f \"" + jarFilePath + "\" ]; then\n"
							+ "sleep 3\n"
							+ "rm \"" + jarFilePath + "\"\n"
							+ "if [ -f \"" + jarFilePath + "\" ]; then\n"
							+ "sleep 3\n"
							+ "rm \"" + jarFilePath + "\"\n"
							+ "if [ -f \"" + jarFilePath + "\" ]; then\n"
							+ "sleep 3\n"
							+ "rm \"" + jarFilePath + "\"\n"
							+ "fi\n"
							+ "fi\n"
							+ "fi\n"
							+ "mv \"" + downloadTempFile.getAbsolutePath() + "\" \"" + jarFilePath + "\"\n"
							+ "if ! [ -f \"" + downloadTempFile.getAbsolutePath() + "\" ]; then\n"
							+ (restartApplicationAfterUpdate ? "\"" + javaBinPath + "\" -jar \"" + jarFilePath + "\"" + (appParameter != null ? " " + appParameter : "") + "\n": "")
							+ "rm \"" + batchFile.getAbsolutePath() + "\"\n"
							+ "fi\n");

			return new String[]{ "sh", batchFile.getAbsolutePath() };
		} else {
			return null;
		}
	}

	public static String[] createRestartBatchFile(final String jarFilePath, final String appParameter) throws Exception {
		String javaBinPath = SystemUtilities.getJavaBinPath();
		if (Utilities.isBlank(javaBinPath)) {
			if (SystemUtilities.isWindowsSystem()) {
				javaBinPath = "java.exe";
			} else {
				javaBinPath = "java";
			}
		}
		if (SystemUtilities.isWindowsSystem()) {
			final File batchFile = new File(new File(jarFilePath).getParent() + File.separator + "restart_" + new File(jarFilePath).getName() + ".cmd");
			if (batchFile.exists()) {
				batchFile.delete();
			}
			writeFile(batchFile,
					"@echo off\r\n"
							+ "ping -n 3 127.0.0.1 >nul\r\n"
							+ "ping -n 3 127.0.0.1 >nul\r\n"
							+ "ping -n 3 127.0.0.1 >nul\r\n"
							+ "ping -n 3 127.0.0.1 >nul\r\n"
							+ "ping -n 3 127.0.0.1 >nul\r\n"
							+ "ping -n 3 127.0.0.1 >nul\r\n"
							+ "ping -n 3 127.0.0.1 >nul\r\n"
							+ "ping -n 3 127.0.0.1 >nul\r\n"
							+ "ping -n 3 127.0.0.1 >nul\r\n"
							+ "ping -n 3 127.0.0.1 >nul\r\n"
							+ "\"" + javaBinPath + "\" -jar \"" + jarFilePath + "\"" + (appParameter != null ? " " + appParameter : "") + "\r\n"
							+ "del \"" + batchFile.getAbsolutePath() + "\"\r\n");

			return new String[]{ "cmd", "/c", "start", "/B", batchFile.getAbsolutePath() };
		} else if (SystemUtilities.isLinuxSystem()) {
			final File batchFile = new File(new File(jarFilePath).getParent() + File.separator + "restart_" + new File(jarFilePath).getName() + ".sh");
			if (batchFile.exists()) {
				batchFile.delete();
			}
			writeFile(batchFile,
					"#!/bin/bash\n"
							+ "sleep 10\n"
							+ "\"" + javaBinPath + "\" -jar \"" + jarFilePath + "\"" + (appParameter != null ? " " + appParameter : "") + "\n"
							+ "rm \"" + batchFile.getAbsolutePath() + "\"\n");

			return new String[]{ "sh", batchFile.getAbsolutePath() };
		} else {
			return null;
		}
	}

	private static String replacePlaceholders(String value) {
		if (value == null) {
			return null;
		} else {
			if (value.contains("<system>")) {
				if (SystemUtilities.isWindowsSystem()) {
					value = value.replace("<system>", "windows");
				} else if (SystemUtilities.isLinuxSystem()) {
					value = value.replace("<system>", "linux");
				}
			}

			if (value.contains("<bitmode>")) {
				if (System.getProperty("os.arch") != null && System.getProperty("os.arch").contains("64")) {
					value = value.replace("<bitmode>", "64");
				} else if (SystemUtilities.isLinuxSystem()) {
					value = value.replace("<bitmode>", "32");
				}
			}

			if (value.contains("<time_seconds>")) {
				value = value.replace("<time_seconds>", "" + (LocalDateTime.now().toEpochSecond(ZoneOffset.UTC)));
			}

			return value;
		}
	}

	private static void writeFile(final File file, final String string) throws Exception {
		try (FileOutputStream out = new FileOutputStream(file)) {
			out.write(string.getBytes(StandardCharsets.UTF_8));
		} catch (final Exception e) {
			throw new Exception("Cannot write file " + file.getAbsolutePath(), e);
		}
	}

	private static boolean downloadUpdateFile(final ApplicationUpdateParent updateParent, final File downloadTempFile, final String downloadUrl, final ProxyConfiguration proxyConfiguration) throws Exception {
		try {
			final WorkerParentSimple workerParentAdapter = new WorkerParentSimple() {
				@Override
				public void receiveUnlimitedProgressSignal() {
					// Do nothing
				}

				@Override
				public void receiveProgressSignal(final LocalDateTime startTime, final long itemsToDo, final long itemsDone, final String itemsUnitSign) {
					if (updateParent != null) {
						updateParent.showUpdateProgress(startTime, itemsToDo, itemsDone, itemsUnitSign);
					}
				}

				@Override
				public void receiveDoneSignal(final LocalDateTime startTime, final LocalDateTime endTime, final long itemsDone, final String itemsUnitSign, final String resultText) {
					if (updateParent != null) {
						updateParent.showUpdateDownloadEnd(startTime, endTime, itemsDone, itemsUnitSign);
					}
				}

				@Override
				public boolean cancel() {
					// Do nothing
					return true;
				}

				@Override
				public void changeTitle(final String text) {
					// do nothing
				}
			};
			final FileDownloadWorker fileDownloadWorker = new FileDownloadWorker(workerParentAdapter, downloadUrl, downloadTempFile).setProxyConfiguration(proxyConfiguration);
			new Thread(fileDownloadWorker).start();

			if (updateParent != null) {
				updateParent.showUpdateDownloadStart(fileDownloadWorker);
			}

			while (!fileDownloadWorker.isDone()) {
				// Wait for download process
				Thread.sleep(1000);
			}

			if (fileDownloadWorker.isCancelled()) {
				return false;
			}

			if (!fileDownloadWorker.get()) {
				throw new Exception("Download was not successful");
			}

			return true;
		} catch (final Exception e) {
			if (e instanceof ExecutionException && e.getCause() instanceof UserError) {
				throw (UserError) e.getCause();
			} else {
				throw e;
			}
		}
	}

	private static boolean copyUpdateFile(final ApplicationUpdateParent updateParent, final File downloadTempFile, final String downloadFile) throws Exception {
		try {
			final WorkerParentSimple workerParentAdapter = new WorkerParentSimple() {
				@Override
				public void receiveUnlimitedProgressSignal() {
					// Do nothing
				}

				@Override
				public void receiveProgressSignal(final LocalDateTime startTime, final long itemsToDo, final long itemsDone, final String itemsUnitSign) {
					if (updateParent != null) {
						updateParent.showUpdateProgress(startTime, itemsToDo, itemsDone, itemsUnitSign);
					}
				}

				@Override
				public void receiveDoneSignal(final LocalDateTime startTime, final LocalDateTime endTime, final long itemsDone, final String itemsUnitSign, final String resultText) {
					if (updateParent != null) {
						updateParent.showUpdateDownloadEnd(startTime, endTime, itemsDone, itemsUnitSign);
					}
				}

				@Override
				public boolean cancel() {
					// Do nothing
					return true;
				}

				@Override
				public void changeTitle(final String text) {
					// do nothing
				}
			};

			final FileCopyWorker fileCopyWorker = new FileCopyWorker(workerParentAdapter, downloadFile, downloadTempFile);
			new Thread(fileCopyWorker).start();

			if (updateParent != null) {
				updateParent.showUpdateDownloadStart(fileCopyWorker);
			}

			while (!fileCopyWorker.isDone()) {
				// Wait for download process
				Thread.sleep(1000);
			}

			if (fileCopyWorker.isCancelled()) {
				return false;
			}

			if (!fileCopyWorker.get()) {
				throw new Exception("Download was not successful");
			}

			return true;
		} catch (final Exception e) {
			if (e instanceof ExecutionException && e.getCause() instanceof UserError) {
				throw (UserError) e.getCause();
			} else {
				throw e;
			}
		}
	}

	private static void showUpdateError(final ApplicationUpdateParent updateParent, final String errorMessage) {
		if (updateParent != null) {
			updateParent.showUpdateError(errorMessage);
		} else {
			// Linebreak to end progress display
			System.err.println("");
			System.err.println(errorMessage);
		}
	}

	public static boolean verifyJarSignature(final File jarFile, final Collection<? extends Certificate> trustedCertificates) {
		if (trustedCertificates == null || trustedCertificates.size() == 0) {
			return false;
		}

		try (JarFile jar = new JarFile(jarFile)) {
			final Manifest manifest = jar.getManifest();
			if (manifest == null) {
				throw new SecurityException("The jar file has no manifest, which contains the file signatures");
			}

			final byte[] buffer = new byte[4096];
			final Enumeration<JarEntry> jarEntriesEnumerator = jar.entries();

			while (jarEntriesEnumerator.hasMoreElements()) {
				final JarEntry jarEntry = jarEntriesEnumerator.nextElement();

				try (InputStream jarEntryInputStream = jar.getInputStream(jarEntry)) {
					// Reading the jarEntry throws a SecurityException if signature/digest check fails.
					while (jarEntryInputStream.read(buffer, 0, buffer.length) != EOF) {
						// just read it
					}
				}

				// Every file must be signed, except for files inside the actual META-INF directory
				if (!jarEntry.isDirectory() && !jarEntry.getName().startsWith("META-INF/")) {
					boolean isSignedByTrustedCert = false;

					final Certificate[] certificates = jarEntry.getCertificates();
					if ((certificates == null) || (certificates.length == 0)) {
						throw new SecurityException("The jar file contains unsigned files: " + jarEntry.getName());
					} else {
						for (final Certificate chainRootCertificate : certificates) {
							if (chainRootCertificate instanceof X509Certificate) {
								final X509Certificate x509ChainRootCertificate = (X509Certificate) chainRootCertificate;
								try {
									x509ChainRootCertificate.checkValidity();
								} catch (@SuppressWarnings("unused") final Exception certificateValidityException) {
									// Certificate is expired or not yet valid, it must not be trusted
									continue;
								}
								if (verifyChainOfTrust(x509ChainRootCertificate, trustedCertificates)) {
									isSignedByTrustedCert = true;
									break;
								}
							}
						}
					}

					if (!isSignedByTrustedCert) {
						throw new SecurityException("The jar file contains untrusted signed files");
					}
				}
			}

			return true;
		} catch (final Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	private static boolean verifyChainOfTrust(final X509Certificate cert, final Collection<? extends Certificate> trustedCertificates) throws Exception {
		final CertPathBuilder certifier = CertPathBuilder.getInstance("PKIX");
		final X509CertSelector targetConstraints = new X509CertSelector();
		targetConstraints.setCertificate(cert);

		final Set<TrustAnchor> trustAnchors = new HashSet<>();
		for (final Certificate trustedRootCert : trustedCertificates) {
			trustAnchors.add(new TrustAnchor((X509Certificate) trustedRootCert, null));
		}

		final PKIXBuilderParameters params = new PKIXBuilderParameters(trustAnchors, targetConstraints);
		// Revocation checking (CRL/OCSP) is disabled deliberately: it would require live network access
		// (CRL/OCSP endpoints) during update verification, which may not be available in all deployment
		// environments. Certificate validity period is checked separately in verifyJarSignature().
		params.setRevocationEnabled(false);
		try {
			final PKIXCertPathBuilderResult result = (PKIXCertPathBuilderResult) certifier.build(params);
			return result != null;
		} catch (@SuppressWarnings("unused") final Exception cpbe) {
			return false;
		}
	}

	public static void removeUpdateLeftovers() {
		final String jarFilePath = SystemUtilities.getCurrentlyRunningJarFilePath();
		if (Utilities.isNotBlank(jarFilePath)) {
			final File updaterFile = new File(new File(jarFilePath).getParent(), "Updater_"+ new File(jarFilePath).getName() +".jar");
			if (updaterFile.exists() && !updaterFile.delete()) {
				System.err.println("Cannot remove leftover updater file '" + updaterFile.getAbsolutePath() + "'");
			}
			final File restarterFile = new File(System.getProperty("java.io.tmpdir"), "Restarter_" + new File(jarFilePath).getName() +".jar");
			if (restarterFile.exists() && !restarterFile.delete()) {
				System.err.println("Cannot remove leftover restarter file '" + restarterFile.getAbsolutePath() + "'");
			}
		}
	}

	/**
	 * Checks whether a GitHub release asset is the executable application jar itself.
	 * Classifier jars like "-sources.jar" or "-javadoc.jar" (also with "_" separator) are excluded,
	 * because the order of assets in GitHub's release API response is not guaranteed.
	 */
	private static boolean isApplicationJarAssetName(final String assetName) {
		if (assetName == null) {
			return false;
		}
		final String assetNameLowerCase = assetName.toLowerCase();
		if (!assetNameLowerCase.endsWith(".jar")) {
			return false;
		}
		for (final String classifier : new String[] { "sources", "javadoc" }) {
			if (assetNameLowerCase.endsWith("-" + classifier + ".jar") || assetNameLowerCase.endsWith("_" + classifier + ".jar")) {
				return false;
			}
		}
		return true;
	}
}
