package de.soderer.utilities.xml;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.StringReader;
import java.io.StringWriter;
import java.net.HttpURLConnection;
import java.net.Proxy;
import java.net.URI;
import java.net.URLConnection;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.bouncycastle.util.Arrays;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.DocumentType;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.EntityResolver;
import org.xml.sax.ErrorHandler;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

import de.soderer.utilities.TextUtilities;
import de.soderer.utilities.Utilities;

/**
 * Utilities class to work with XML documents.
 */
public class XmlUtilities {
	/**
	 * Creates a DocumentBuilderFactory that is hardened against XXE attacks
	 * (external entity resolution, external DTD loading, XInclude).
	 * Use this instead of calling DocumentBuilderFactory.newInstance() directly.
	 */
	private static DocumentBuilderFactory createSecureDocumentBuilderFactory() throws ParserConfigurationException {
		final DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
		documentBuilderFactory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
		documentBuilderFactory.setFeature("http://xml.org/sax/features/external-general-entities", false);
		documentBuilderFactory.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
		documentBuilderFactory.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);
		documentBuilderFactory.setXIncludeAware(false);
		documentBuilderFactory.setExpandEntityReferences(false);
		return documentBuilderFactory;
	}

	/**
	 * Same hardening as {@link #createSecureDocumentBuilderFactory()}, but still allows a DOCTYPE
	 * declaration to be present (needed e.g. for XHTML documents). External entities and external
	 * DTDs are still never resolved/loaded, which is what actually prevents XXE.
	 */
	private static DocumentBuilderFactory createSecureDocumentBuilderFactoryAllowingDoctype() throws ParserConfigurationException {
		final DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
		documentBuilderFactory.setFeature("http://xml.org/sax/features/external-general-entities", false);
		documentBuilderFactory.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
		documentBuilderFactory.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);
		documentBuilderFactory.setXIncludeAware(false);
		return documentBuilderFactory;
	}

	public static boolean isXmlDocument(final byte[] data) {
		if (data == null || data.length < 6) {
			return false;
		} else {
			return "<?xml ".equals(new String(Arrays.copyOfRange(data, 0, 6), StandardCharsets.UTF_8).toLowerCase());
		}
	}

	/**
	 * Gets the empty document.
	 *
	 * @return the empty document
	 * @throws ParserConfigurationException
	 *             the parser configuration exception
	 */
	public static Document getEmptyDocument() throws ParserConfigurationException {
		final DocumentBuilderFactory documentBuilderFactory = createSecureDocumentBuilderFactory();
		final DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
		final Document document = documentBuilder.newDocument();
		return document;
	}

	/**
	 * Download and parse xml file.
	 * Does not follow redirection (HTTP Code 302, 301 and others)
	 *
	 * @param url
	 *            the url
	 * @return the document
	 * @throws IOException
	 *             the IO exception
	 */
	public static Document downloadAndParseXmlFile(final String url, final Proxy proxy) throws Exception {
		final URLConnection urlConnection;
		if (proxy == null) {
			urlConnection = URI.create(url).toURL().openConnection();
		} else {
			urlConnection = URI.create(url).toURL().openConnection(proxy);
		}

		try (BufferedInputStream inputStream = new BufferedInputStream(urlConnection.getInputStream())) {
			final DocumentBuilderFactory documentBuilderFactory = createSecureDocumentBuilderFactory();
			final DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
			final Document document = documentBuilder.parse(new InputSource(inputStream));
			return document;
		} catch (final Exception e) {
			final HttpURLConnection urlConnection2;
			if (proxy == null) {
				urlConnection2 = (HttpURLConnection) URI.create(url).toURL().openConnection();
			} else {
				urlConnection2 = (HttpURLConnection) URI.create(url).toURL().openConnection(proxy);
			}

			urlConnection2.connect();
			final int httpCode = urlConnection2.getResponseCode();
			if (httpCode != 200) {
				throw new Exception("Cannot retrieve xml document from Url '" + url + "'. HTTP code was: " + httpCode);
			} else {
				throw e;
			}
		}
	}

	/**
	 * Parse xml file.
	 *
	 * @param file
	 *            the file
	 * @return the document
	 */
	public static Document parseXmlFile(final File file) {
		try (BufferedInputStream inputStream = new BufferedInputStream(new FileInputStream(file))) {
			final DocumentBuilderFactory documentBuilderFactory = createSecureDocumentBuilderFactory();
			final DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
			final Document document = documentBuilder.parse(new InputSource(inputStream));
			return document;
		} catch (@SuppressWarnings("unused") final Exception e) {
			return null;
		}
	}


	/**
	 * Parse xml bytearray.
	 *
	 * @param xmlData bytearray
	 * @return the document
	 */
	public static Document parseXmlFile(final byte[] xmlData) {
		try (BufferedInputStream inputStream = new BufferedInputStream(new ByteArrayInputStream(xmlData))) {
			final DocumentBuilderFactory documentBuilderFactory = createSecureDocumentBuilderFactory();
			final DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
			final Document document = documentBuilder.parse(inputStream);
			return document;
		} catch (@SuppressWarnings("unused") final Exception e) {
			return null;
		}
	}

	/**
	 * Gets a single x path node.
	 *
	 * @param document
	 *            the document
	 * @param xpathExpression
	 *            the xpath expression
	 * @return the single x path node
	 */
	public static Node getSingleXPathNode(final Document document, final String xpathExpression) {
		if (document == null) {
			return null;
		} else if (Utilities.isBlank(xpathExpression)) {
			return null;
		} else {
			try {
				final NodeList nodeList = (NodeList) XPathFactory.newInstance().newXPath().evaluate(xpathExpression, document, XPathConstants.NODESET);
				if (nodeList != null && nodeList.getLength() > 0) {
					return nodeList.item(0);
				} else {
					return null;
				}
			} catch (@SuppressWarnings("unused") final XPathExpressionException e) {
				return null;
			}
		}
	}

	/**
	 * Parses a xml string.
	 *
	 * @param xmlInput
	 *            the xml input
	 * @return the document
	 * @throws Exception
	 *             the exception
	 */
	public static Document parseXmlString(final String xmlInput) throws Exception {
		final boolean validation = false;
		final boolean ignoreWhitespace = true;
		final boolean ignoreComments = true;
		final boolean putCDATAIntoText = true;
		final boolean createEntityRefs = false;

		final DocumentBuilderFactory dbf = createSecureDocumentBuilderFactory();

		// set the configuration options
		dbf.setValidating(validation);
		dbf.setIgnoringComments(ignoreComments);
		dbf.setIgnoringElementContentWhitespace(ignoreWhitespace);
		dbf.setCoalescing(putCDATAIntoText);
		// The opposite of creating entity ref nodes is expanding them inline
		dbf.setExpandEntityReferences(!createEntityRefs);

		DocumentBuilder db = null;
		Document doc = null;
		try {
			db = dbf.newDocumentBuilder();
			doc = db.parse(new InputSource(new StringReader(xmlInput)));
			return doc;

		} catch (final Exception e) {
			throw new Exception("Error while parsing xml", e);
		}
	}

	/**
	 * Ignores DTD for better performance. This works faster for XHTML, because it doesn't download the dtd from any website like "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"
	 *
	 * @param xmlInput
	 *            the xml input
	 * @return the document
	 * @throws Exception
	 *             the exception
	 */
	public static Document parseXmlStringIngoringDtd(final String xmlInput) throws Exception {
		if (xmlInput == null) {
			throw new Exception("XML-Data is null");
		} else if (Utilities.isBlank(xmlInput)) {
			throw new Exception("XML-Data is empty");
		}

		final boolean validation = false;
		final boolean ignoreWhitespace = true;
		final boolean ignoreComments = true;
		final boolean putCDATAIntoText = true;
		final boolean createEntityRefs = false;

		final DocumentBuilderFactory dbf = createSecureDocumentBuilderFactoryAllowingDoctype();

		// set the configuration options
		dbf.setValidating(validation);
		dbf.setIgnoringComments(ignoreComments);
		dbf.setIgnoringElementContentWhitespace(ignoreWhitespace);
		dbf.setCoalescing(putCDATAIntoText);
		// The opposite of creating entity ref nodes is expanding them inline
		dbf.setExpandEntityReferences(!createEntityRefs);

		DocumentBuilder db = null;
		Document doc = null;
		try {
			db = dbf.newDocumentBuilder();

			db.setEntityResolver(new EntityResolver() {
				@Override
				public InputSource resolveEntity(final String publicId, final String systemId) throws SAXException, IOException {
					return new InputSource(new StringReader(""));
				}
			});

			doc = db.parse(new InputSource(new StringReader(xmlInput)));
			return doc;
		} catch (final Exception e) {
			throw new Exception("Error while parsing xml", e);
		}
	}

	/**
	 * Returns the content of a simple text tag If there are more than one text node or other nodetypes it will return null.
	 *
	 * @param node
	 *            the node
	 * @return the simple text value from node
	 */
	public static String getSimpleTextValueFromNode(final Node node) {
		if (node != null && node.getChildNodes().getLength() == 1 && node.getChildNodes().item(0).getNodeType() == Node.TEXT_NODE) {
			return node.getChildNodes().item(0).getTextContent();
		} else {
			return null;
		}
	}

	/**
	 * Gets a attribute value.
	 *
	 * @param pNode
	 *            the p node
	 * @param pAttributeName
	 *            the p attribute name
	 * @return the attribute value
	 */
	public static String getAttributeValue(final Node pNode, final String pAttributeName) {
		String returnString = null;

		final NamedNodeMap attributes = pNode.getAttributes();
		if (attributes != null) {
			for (int i = 0; i < attributes.getLength(); i++) {
				if (attributes.item(i).getNodeName().equalsIgnoreCase(pAttributeName)) {
					returnString = attributes.item(i).getNodeValue();
					break;
				}
			}
		}

		return returnString;
	}

	/**
	 * Gets a node value.
	 *
	 * @param pNode
	 *            the p node
	 * @return the node value
	 */
	public static String getNodeValue(final Node pNode) {
		if (pNode.getNodeValue() != null) {
			return pNode.getNodeValue();
		} else if (pNode.getFirstChild() != null) {
			return getNodeValue(pNode.getFirstChild());
		} else {
			return null;
		}
	}

	/**
	 * Gets the node as string.
	 *
	 * @param pNode
	 *            the p node
	 * @param encoding
	 *            the encoding
	 * @param pRemoveXmlLine
	 *            the p remove xml line
	 * @return the node as string
	 * @throws Exception
	 *             the exception
	 */
	public static String getNodeAsString(final Node pNode, final Charset encoding, final boolean pRemoveXmlLine) throws Exception {
		final StringWriter writer = new StringWriter();
		final StreamResult result = new StreamResult(writer);
		transformNode(pNode, encoding, pRemoveXmlLine, result);
		return writer.toString();
	}

	/**
	 * Gets the node as raw.
	 *
	 * @param pNode
	 *            the p node
	 * @param encoding
	 *            the encoding
	 * @param pRemoveXmlLine
	 *            the p remove xml line
	 * @return the node as raw
	 * @throws Exception
	 *             the exception
	 */
	public static byte[] getNodeAsRaw(final Node pNode, final Charset encoding, final boolean pRemoveXmlLine) throws Exception {
		final ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		final StreamResult result = new StreamResult(outputStream);
		transformNode(pNode, encoding, pRemoveXmlLine, result);
		return outputStream.toByteArray();
	}

	/**
	 * Write document to file.
	 *
	 * @param document
	 *            the document
	 * @param encoding
	 *            the encoding
	 * @param file
	 *            the file
	 * @throws Exception
	 *             the exception
	 */
	public static void writeDocumentToFile(final Document document, final Charset encoding, final File file) throws Exception {
		try (OutputStream outputStream = new FileOutputStream(file)) {
			final StreamResult result = new StreamResult(outputStream);
			transformNode(document, encoding, false, result);
		}
	}

	/**
	 * Transform node.
	 *
	 * @param node
	 *            the node
	 * @param encoding
	 *            the encoding
	 * @param removeXmlHeader
	 *            the remove xml header
	 * @param result
	 *            the result
	 * @throws Exception
	 *             the exception
	 */
	private static void transformNode(final Node node, final Charset encoding, final boolean removeXmlHeader, final StreamResult result) throws Exception {
		TransformerFactory transformerFactory = null;
		Transformer transformer = null;
		DOMSource source = null;

		try {
			transformerFactory = TransformerFactory.newInstance();
			if (transformerFactory == null) {
				throw new Exception("TransformerFactory error");
			}

			transformer = transformerFactory.newTransformer();
			if (transformer == null) {
				throw new Exception("Transformer error");
			}

			transformer.setOutputProperty(OutputKeys.ENCODING, encoding.name());
			if (removeXmlHeader) {
				transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
			} else {
				transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "no");
			}

			source = new DOMSource(node);

			transformer.transform(source, result);
		} catch (final TransformerFactoryConfigurationError e) {
			throw new Exception("TransformerFactoryConfigurationError", e);
		} catch (final TransformerConfigurationException e) {
			throw new Exception("TransformerConfigurationException", e);
		} catch (final TransformerException e) {
			throw new Exception("TransformerException", e);
		}
	}

	/**
	 * Parses the xml data and xsd verify by dom.
	 *
	 * @param pData
	 *            the p data
	 * @param byteEncoding
	 *            the byte encoding
	 * @param xsdFileName
	 *            the xsd file name
	 * @return the document
	 * @throws Exception
	 *             the exception
	 * @throws Exception
	 *             the exception
	 */
	public static Document parseXMLDataAndXSDVerifyByDOM(byte[] pData, final String byteEncoding, final String xsdFileName) throws Exception, Exception {
		try {
			if (pData == null) {
				return null;
			}

			if (pData[pData.length - 1] == 0) {
				pData = new String(pData, StandardCharsets.UTF_8).trim().getBytes(StandardCharsets.UTF_8);
			}

			final DocumentBuilderFactory docBuilderFactory = createSecureDocumentBuilderFactory();
			if (docBuilderFactory == null) {
				throw new Exception("DocumentBuilderFactory error");
			}
			docBuilderFactory.setNamespaceAware(true);

			if (xsdFileName != null) {
				final String schemaURI = xsdFileName;
				docBuilderFactory.setValidating(true);
				docBuilderFactory.setAttribute("http://java.sun.com/xml/jaxp/properties/schemaLanguage", "http://www.w3.org/2001/XMLSchema");
				docBuilderFactory.setAttribute("http://java.sun.com/xml/jaxp/properties/schemaSource", schemaURI);
			}

			final DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
			if (docBuilder == null) {
				throw new Exception("DocumentBuilder error");
			}

			final InputSource inputSource = new InputSource(new ByteArrayInputStream(pData));
			if (byteEncoding != null) {
				inputSource.setEncoding(byteEncoding);
			}
			final ParseErrorHandler errorHandler = new ParseErrorHandler();
			docBuilder.setErrorHandler(errorHandler);

			final Document xmlDocument = docBuilder.parse(inputSource);

			if (errorHandler.problemsOccurred()) {
				throw new Exception("ErrorConstGlobals.XML_SCHEMA_ERROR " + xsdFileName + " " + errorHandler.getMessage());
			} else {
				return xmlDocument;
			}
		} catch (final ParserConfigurationException e) {
			throw new Exception("ErrorConstException.XML_PROCESSING " + e.getClass().getSimpleName() + " " + e.getMessage(), e);
		} catch (final SAXException e) {
			throw new Exception("ErrorConstException.XML_PROCESSING " + e.getClass().getSimpleName() + " " + e.getMessage(), e);
		} catch (final IOException e) {
			throw new Exception("ErrorConstException.XML_PROCESSING " + e.getClass().getSimpleName() + " " + e.getMessage(), e);
		}
	}

	/**
	 * The Class ParseErrorHandler.
	 */
	private static class ParseErrorHandler implements ErrorHandler {

		/** The warnings. */
		ArrayList<SAXParseException> warnings = null;

		/** The errors. */
		ArrayList<SAXParseException> errors = null;

		/** The fatal errors. */
		ArrayList<SAXParseException> fatalErrors = null;

		/** The problems. */
		boolean problems = false;

		/**
		 * Problems occurred.
		 *
		 * @return true, if problems occurred
		 */
		public boolean problemsOccurred() {
			return problems;
		}

		/*
		 * (non-Javadoc)
		 *
		 * @see org.xml.sax.ErrorHandler#warning(org.xml.sax.SAXParseException)
		 */
		@Override
		public void warning(final SAXParseException exception) throws SAXException {
			problems = true;
			if (warnings == null) {
				warnings = new ArrayList<>();
			}
			warnings.add(exception);
		}

		/*
		 * (non-Javadoc)
		 *
		 * @see org.xml.sax.ErrorHandler#error(org.xml.sax.SAXParseException)
		 */
		@Override
		public void error(final SAXParseException exception) throws SAXException {
			problems = true;
			if (errors == null) {
				errors = new ArrayList<>();
			}
			errors.add(exception);
		}

		/*
		 * (non-Javadoc)
		 *
		 * @see org.xml.sax.ErrorHandler#fatalError(org.xml.sax.SAXParseException)
		 */
		@Override
		public void fatalError(final SAXParseException exception) throws SAXException {
			problems = true;
			if (fatalErrors == null) {
				fatalErrors = new ArrayList<>();
			}
			fatalErrors.add(exception);
		}

		/**
		 * Gets the message.
		 *
		 * @return the message
		 */
		public String getMessage() {
			if (fatalErrors != null && fatalErrors.size() > 0) {
				return fatalErrors.get(0).getMessage();
			} else if (errors != null && errors.size() > 0) {
				return errors.get(0).getMessage();
			} else if (warnings != null && warnings.size() > 0) {
				return warnings.get(0).getMessage();
			} else {
				return "No ParserErrors occured";
			}
		}
	}

	/**
	 * Convert xml to string.
	 *
	 * @param pDocument
	 *            the p document
	 * @param encoding
	 *            the encoding
	 * @return the string
	 * @throws Exception
	 *             the exception
	 */
	public static String convertXML2String(final Document pDocument, final Charset encoding) throws Exception {
		TransformerFactory transformerFactory = null;
		Transformer transformer = null;
		DOMSource domSource = null;
		StreamResult result = null;

		try {
			transformerFactory = TransformerFactory.newInstance();
			if (transformerFactory == null) {
				throw new Exception("TransformerFactory error");
			}

			transformer = transformerFactory.newTransformer();
			if (transformer == null) {
				throw new Exception("Transformer error");
			}

			if (encoding != null) {
				transformer.setOutputProperty(OutputKeys.ENCODING, encoding.name());
			} else {
				transformer.setOutputProperty(OutputKeys.ENCODING, StandardCharsets.UTF_8.name());
			}

			domSource = new DOMSource(pDocument);
			try (StringWriter writer = new java.io.StringWriter()) {
				result = new StreamResult(writer);

				transformer.transform(domSource, result);

				return writer.toString();
			}
		} catch (final TransformerFactoryConfigurationError e) {
			throw new Exception("TransformerFactoryConfigurationError", e);
		} catch (final TransformerConfigurationException e) {
			throw new Exception("TransformerConfigurationException", e);
		} catch (final TransformerException e) {
			throw new Exception("TransformerException", e);
		}
	}

	/**
	 * Convert xml to byte array.
	 *
	 * @param pDocument
	 *            the p document
	 * @param encoding
	 *            the encoding
	 * @return the byte[]
	 * @throws Exception
	 *             the exception
	 */
	public static byte[] convertXML2ByteArray(final Node pDocument, final Charset encoding) throws Exception {
		TransformerFactory transformerFactory = null;
		Transformer transformer = null;
		DOMSource domSource = null;
		StreamResult result = null;

		try {
			transformerFactory = TransformerFactory.newInstance();
			if (transformerFactory == null) {
				throw new Exception("TransformerFactory error");
			}

			transformer = transformerFactory.newTransformer();
			if (transformer == null) {
				throw new Exception("Transformer error");
			}

			if (encoding != null) {
				transformer.setOutputProperty(OutputKeys.ENCODING, encoding.name());
			} else {
				transformer.setOutputProperty(OutputKeys.ENCODING, StandardCharsets.UTF_8.name());
			}

			domSource = new DOMSource(pDocument);
			try (ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {
				result = new StreamResult(outputStream);

				transformer.transform(domSource, result);

				return outputStream.toByteArray();
			}
		} catch (final TransformerFactoryConfigurationError e) {
			throw new Exception("TransformerFactoryConfigurationError", e);
		} catch (final TransformerConfigurationException e) {
			throw new Exception("TransformerConfigurationException", e);
		} catch (final TransformerException e) {
			throw new Exception("TransformerException", e);
		}
	}

	// public static void parseXMLDataAndXSDVerifyBySAX(byte[] pUploadXmlDocumentArray, UploadXMLContentHandler pContentHandler) throws Exception, Exception {
	// try {
	// if (pUploadXmlDocumentArray == null || pUploadXmlDocumentArray.length == 0) {
	// throw new Exception(ErrorConstAtsGlobals.UPLOAD_XML_EMPTY);
	// }
	// if (pUploadXmlDocumentArray[0] != "<".getBytes(StandardCharsets.UTF_8)[0]) {
	// throw new Exception(ErrorConstAtsGlobals.INVALID_XML_DATA, "XML data is invalid");
	// }
	//
	// SAXParser parser = new SAXParser();
	// String schemaFileName = pContentHandler.getSchemaFileName();
	// if (schemaFileName != null) {
	// URI schemaFileURI = Utilities.getResource(schemaFileName);
	// if (schemaFileURI == null) {
	// throw new Exception("XML-Schema was not found: " + schemaFileName);
	// }
	// parser.setFeature("http://xml.org/sax/features/validation", true);
	// parser.setFeature("http://apache.org/xml/features/validation/schema", true);
	// parser.setFeature("http://apache.org/xml/features/validation/schema-full-checking", true);
	// parser.setProperty("http://apache.org/xml/properties/schema/external-noNamespaceSchemaLocation", schemaFileURI.toString());
	// }
	//
	// parser.setContentHandler(pContentHandler);
	//
	// ParseErrorHandler errorHandler = new ParseErrorHandler();
	// parser.setErrorHandler(errorHandler);
	//
	// InputSource inputSource = new InputSource(new ByteArrayInputStream(pUploadXmlDocumentArray));
	// parser.parse(inputSource);
	//
	// if (errorHandler.problemsOccurred()) {
	// throw new Exception(ErrorConstAtsGlobals.XML_SCHEMA_ERROR, pContentHandler.getSchemaFileName(), errorHandler.getMessage());
	// }
	//
	// /*
	// * String parserClass = "org.apache.xerces.parsers.SAXParser"; String validationFeature = "http://xml.org/sax/features/validation"; String schemaFeature =
	// * "http://apache.org/xml/features/validation/schema";
	// *
	// * XMLReader r = XMLReaderFactory.createXMLReader(parserClass); r.setFeature(validationFeature,true); r.setFeature(schemaFeature,true);
	// *
	// * InputSource inputSourcSAX = new InputSource(pDataStream);
	// * if (byteEncoding != null) {
	// * inputSourcSAX.setEncoding(byteEncoding);
	// * }
	// * ParseErrorHandler errorHandlerSax = new ParseErrorHandler();
	// * r.setErrorHandler(errorHandlerSax); r.parse(inputSourcSAX);
	// */
	// } catch (SAXException e) {
	// logger.error(e.getClass().getSimpleName(), e);
	// throw new Exception(ErrorConstException.XML_PROCESSING, e.getClass().getSimpleName(), e.getMessage());
	// } catch (IOException e) {
	// logger.error(e.getClass().getSimpleName() + " while XML processing", e);
	// throw new Exception(ErrorConstException.XML_PROCESSING, e.getClass().getSimpleName(), e.getMessage());
	// }
	// }

	/**
	 * Creates the root tag node.
	 *
	 * @param baseDocument
	 *            the base document
	 * @param rootTagName
	 *            the root tag name
	 * @return the element
	 */
	public static Element createRootTagNode(final Document baseDocument, final String rootTagName) {
		final Element newNode = baseDocument.createElement(rootTagName);
		baseDocument.appendChild(newNode);
		return newNode;
	}

	/**
	 * Append node.
	 *
	 * @param baseNode
	 *            the base node
	 * @param tagName
	 *            the tag name
	 * @return the element
	 */
	public static Element appendNode(final Node baseNode, final String tagName) {
		final Element newNode = baseNode.getOwnerDocument().createElement(tagName);
		baseNode.appendChild(newNode);
		return newNode;
	}

	/**
	 * Append text value node.
	 *
	 * @param baseNode
	 *            the base node
	 * @param tagName
	 *            the tag name
	 * @param tagValue
	 *            the tag value
	 * @return the element
	 */
	public static Element appendTextValueNode(final Node baseNode, final String tagName, final int tagValue) {
		return appendTextValueNode(baseNode, tagName, Integer.toString(tagValue));
	}

	/**
	 * Append text value node.
	 *
	 * @param baseNode
	 *            the base node
	 * @param tagName
	 *            the tag name
	 * @param tagValue
	 *            the tag value
	 * @return the element
	 */
	public static Element appendTextValueNode(final Node baseNode, final String tagName, final double tagValue) {
		return appendTextValueNode(baseNode, tagName, Double.toString(tagValue));
	}

	/**
	 * Append text value node.
	 *
	 * @param baseNode
	 *            the base node
	 * @param tagName
	 *            the tag name
	 * @param tagValue
	 *            the tag value
	 * @return the element
	 */
	public static Element appendTextValueNode(final Node baseNode, final String tagName, final String tagValue) {
		final Element newNode = appendNode(baseNode, tagName);
		if (tagValue == null) {
			newNode.appendChild(baseNode.getOwnerDocument().createTextNode("<null>"));
		} else {
			newNode.appendChild(baseNode.getOwnerDocument().createTextNode(tagValue));
		}
		return newNode;
	}

	/**
	 * Append attribute.
	 *
	 * @param baseNode
	 *            the base node
	 * @param attributeName
	 *            the attribute name
	 * @param attributeValue
	 *            the attribute value
	 */
	public static void appendAttribute(final Element baseNode, final String attributeName, final boolean attributeValue) {
		appendAttribute(baseNode, attributeName, attributeValue ? "true" : "false");
	}

	/**
	 * Append attribute.
	 *
	 * @param baseNode
	 *            the base node
	 * @param attributeName
	 *            the attribute name
	 * @param attributeValue
	 *            the attribute value
	 */
	public static void appendAttribute(final Element baseNode, final String attributeName, final int attributeValue) {
		appendAttribute(baseNode, attributeName, Integer.toString(attributeValue));
	}

	/**
	 * Append attribute.
	 *
	 * @param baseNode
	 *            the base node
	 * @param attributeName
	 *            the attribute name
	 * @param attributeValue
	 *            the attribute value
	 */
	public static void appendAttribute(final Element baseNode, final String attributeName, final String attributeValue) {
		final Attr typeAttribute = baseNode.getOwnerDocument().createAttribute(attributeName);
		if (attributeValue == null) {
			typeAttribute.setNodeValue("<null>");
		} else {
			typeAttribute.setNodeValue(attributeValue);
		}
		baseNode.setAttributeNode(typeAttribute);
	}

	/**
	 * Removes the attribute.
	 *
	 * @param baseNode
	 *            the base node
	 * @param attributeName
	 *            the attribute name
	 */
	public static void removeAttribute(final Element baseNode, final String attributeName) {
		baseNode.getAttributes().removeNamedItem(attributeName);
	}

	/**
	 * Adds the comment to document.
	 *
	 * @param pDocument
	 *            the p document
	 * @param pComment
	 *            the p comment
	 * @return the document
	 */
	public static Document addCommentToDocument(final Document pDocument, final String pComment) {
		pDocument.getFirstChild().appendChild(pDocument.createComment(pComment));
		return pDocument;
	}

	/**
	 * Gets the encoding of xml byte array.
	 *
	 * @param xmlData
	 *            the xml data
	 * @return the encoding of xml byte array
	 * @throws Exception
	 *             the exception
	 */
	public static Charset getEncodingOfXmlByteArray(final byte[] xmlData) throws Exception {
		final String encodingAttributeName = "ENCODING";
		final String first50CharactersInUtf8UpperCase = new String(xmlData, StandardCharsets.UTF_8).substring(0, 50).toUpperCase();
		if (first50CharactersInUtf8UpperCase.contains(encodingAttributeName)) {
			final int encodingstart = first50CharactersInUtf8UpperCase.indexOf(encodingAttributeName) + encodingAttributeName.length();

			final int contentStartEinfach = first50CharactersInUtf8UpperCase.indexOf("'", encodingstart);
			final int contentStartDoppelt = first50CharactersInUtf8UpperCase.indexOf("\"", encodingstart);
			int contentStart = Math.min(contentStartEinfach, contentStartDoppelt);
			if (contentStartEinfach < 0) {
				contentStart = contentStartDoppelt;
			}
			if (contentStart < 0) {
				throw new Exception("XmlByteArray-Encoding nicht ermittelbar");
			}
			contentStart = contentStart + 1;

			final int contentEndSingle = first50CharactersInUtf8UpperCase.indexOf("'", contentStart);
			final int contentEndDouble = first50CharactersInUtf8UpperCase.indexOf("\"", contentStart);
			int contentEnd = Math.min(contentEndSingle, contentEndDouble);
			if (contentEndSingle < 0) {
				contentEnd = contentEndDouble;
			}
			if (contentEnd < 0) {
				throw new Exception("XmlByteArray-Encoding nicht ermittelbar");
			}

			final String encodingString = first50CharactersInUtf8UpperCase.substring(contentStart, contentEnd);
			return Charset.forName(encodingString);
		} else {
			throw new Exception("XmlByteArray-Encoding nicht ermittelbar");
		}
	}

	/**
	 * Returns all direct simple text value subnodes and their values for a dataNode
	 *
	 * Example XML: <dataNode> <a>1</a> <b>2</b> <c>3</c> </dataNode> Returns: a=1, b=2, c=3.
	 *
	 * @param dataNode
	 *            the data node
	 * @return the simple values of node
	 */
	public static Map<String, String> getSimpleValuesOfNode(final Node dataNode) {
		final Map<String, String> returnMap = new HashMap<>();

		final NodeList list = dataNode.getChildNodes();
		for (int i = 0; i < list.getLength(); i++) {
			final Node node = list.item(i);
			if (node.getFirstChild() != null && node.getFirstChild().getNodeType() == Node.TEXT_NODE && node.getChildNodes().getLength() == 1) {
				returnMap.put(node.getNodeName(), node.getFirstChild().getNodeValue());
			}
		}

		return returnMap;
	}

	/**
	 * Gets the sub nodes.
	 *
	 * @param dataNode
	 *            the data node
	 * @return the sub nodes
	 */
	public static List<Node> getSubNodes(final Node dataNode) {
		final List<Node> returnList = new ArrayList<>();

		final NodeList list = dataNode.getChildNodes();
		for (int i = 0; i < list.getLength(); i++) {
			final Node node = list.item(i);
			returnList.add(node);
		}

		return returnList;
	}

	public static Map<String, Node> getChildNodesMap(final Node dataNode) {
		final Map<String, Node> childNodes = new HashMap<>();
		final NodeList childNodesList = dataNode.getChildNodes();
		for (int i = 0; i < childNodesList.getLength(); i++) {
			final Node childNode = childNodesList.item(i);
			if (childNode.getNodeType() != Node.TEXT_NODE) {
				childNodes.put(childNode.getNodeName(), childNode);
			}
		}

		return childNodes;
	}

	/**
	 * Gets the nodenames of childs.
	 *
	 * @param dataNode
	 *            the data node
	 * @return the nodenames of childs
	 */
	public static List<String> getNodenamesOfChilds(final Node dataNode) {
		final List<String> returnList = new ArrayList<>();

		final NodeList list = dataNode.getChildNodes();
		for (int i = 0; i < list.getLength(); i++) {
			final Node node = list.item(i);
			if (node.getNodeType() != Node.TEXT_NODE) {
				returnList.add(node.getNodeName());
			}
		}

		return returnList;
	}

	public static String removeFrameTag(final String data) throws Exception {
		if (Utilities.isEmpty(data)) {
			return data;
		} else {
			final String changedData = data.trim();
			if (changedData.startsWith("<") && changedData.endsWith(">")) {
				final Document xmlDocument = parseXmlString(changedData);
				final Node rootNode = getRootNodeFromDocument(xmlDocument);
				final List<Node> childNodes = getChildNodes(rootNode);
				if (childNodes.size() > 0) {
					return getNodeAsString(childNodes.get(0), StandardCharsets.UTF_8, true);
				} else {
					return getNodeValue(rootNode);
				}
			} else {
				return data;
			}
		}
	}

	public static Node getRootNodeFromDocument(final Document document) {
		return document.getDocumentElement();
	}

	public static List<Node> getChildNodes(final Node dataNode) {
		final List<Node> returnList = new ArrayList<>();

		final NodeList list = dataNode.getChildNodes();
		for (int i = 0; i < list.getLength(); i++) {
			final Node node = list.item(i);
			if (node.getNodeType() != Node.TEXT_NODE) {
				returnList.add(node);
			}
		}

		return returnList;
	}

	public static String formatXmlDocument(final Document xmlDocument, final Charset encoding, final boolean throwExceptionOnError) {
		try {
			final StringBuilder result = new StringBuilder();
			result.append("<?xml version=\"");
			result.append(xmlDocument.getXmlVersion());
			result.append("\" encoding=\"");
			result.append(encoding.name().toUpperCase());
			result.append("\" standalone=\"");
			result.append(xmlDocument.getXmlStandalone() ? "yes" : "no");
			result.append("\"?>\n");

			for (int i = 0; i < xmlDocument.getChildNodes().getLength(); i++) {
				final Node xmlNode = xmlDocument.getChildNodes().item(i);
				result.append(formatXmlNode(xmlNode, 0));
			}
			return result.toString();
		} catch (final Exception e) {
			if (throwExceptionOnError) {
				throw e;
			} else {
				return null;
			}
		}
	}

	public static String formatXmlDocument(final Document xmlDocument, final boolean throwExceptionOnError) {
		try {
			final StringBuilder result = new StringBuilder();
			result.append("<?xml version=\"");
			result.append(xmlDocument.getXmlVersion());
			result.append("\" encoding=\"");
			result.append(xmlDocument.getXmlEncoding() == null ? StandardCharsets.UTF_8 : xmlDocument.getXmlEncoding());
			result.append("\" standalone=\"");
			result.append(xmlDocument.getXmlStandalone() ? "yes" : "no");
			result.append("\"?>\n");

			for (int i = 0; i < xmlDocument.getChildNodes().getLength(); i++) {
				final Node xmlNode = xmlDocument.getChildNodes().item(i);
				result.append(formatXmlNode(xmlNode, 0));
			}
			return result.toString();
		} catch (final Exception e) {
			if (throwExceptionOnError) {
				throw e;
			} else {
				return null;
			}
		}
	}

	public static String formatXmlNode(final Node xmlNode, final int indentationLevel) {
		if (xmlNode.getNodeType() == Node.TEXT_NODE) {
			if (Utilities.isBlank(xmlNode.getNodeValue())) {
				return "";
			} else {
				return xmlNode.getNodeValue().replace("&", "&amp;").replace("<", "&lt;");
			}
		} else if (xmlNode.getNodeType() == Node.COMMENT_NODE) {
			if (Utilities.isBlank(xmlNode.getNodeValue())) {
				return "";
			} else {
				final StringBuilder result = new StringBuilder();
				result.append(TextUtilities.repeatString("\t", indentationLevel));
				result.append("<!--");
				result.append(xmlNode.getNodeValue().replace("&", "&amp;").replace("<", "&lt;"));
				result.append("-->\n");
				return result.toString();
			}
		} else if (xmlNode.getNodeType() == Node.DOCUMENT_TYPE_NODE) {
			final StringBuilder result = new StringBuilder();
			result.append(TextUtilities.repeatString("\t", indentationLevel));
			result.append("<!DOCTYPE ");
			result.append(((DocumentType) xmlNode).getName());
			result.append(" PUBLIC \"");
			result.append(((DocumentType) xmlNode).getPublicId());
			result.append("\" \"");
			result.append(((DocumentType) xmlNode).getSystemId());
			result.append("\">\n");
			return result.toString();
		} else if (xmlNode.getChildNodes().getLength() == 1 && xmlNode.getChildNodes().item(0).getNodeType() == Node.TEXT_NODE) {
			if (Utilities.isBlank(xmlNode.getChildNodes().item(0).getNodeValue())) {
				final StringBuilder result = new StringBuilder();
				result.append(TextUtilities.repeatString("\t", indentationLevel));
				result.append("<");
				result.append(xmlNode.getNodeName());
				result.append(formatAttributes(xmlNode, indentationLevel));
				result.append(" />\n");
				return result.toString();
			} else {
				final StringBuilder result = new StringBuilder();
				result.append(TextUtilities.repeatString("\t", indentationLevel));
				result.append("<");
				result.append(xmlNode.getNodeName());
				result.append(formatAttributes(xmlNode, indentationLevel));
				result.append(">");
				result.append(xmlNode.getChildNodes().item(0).getNodeValue().replace("&", "&amp;").replace("<", "&lt;"));
				result.append("</");
				result.append(xmlNode.getNodeName());
				result.append(">\n");
				return result.toString();
			}
		} else {
			final StringBuilder innerXml = new StringBuilder();
			if (xmlNode.getChildNodes() != null && xmlNode.getChildNodes().getLength() > 0) {
				for (int nodeIndex = 0; nodeIndex < xmlNode.getChildNodes().getLength(); nodeIndex++) {
					final Node xmlSubNode = xmlNode.getChildNodes().item(nodeIndex);
					if (xmlSubNode.getNodeType() == Node.TEXT_NODE) {
						if (Utilities.isNotBlank(xmlSubNode.getNodeValue())) {
							innerXml.append(xmlSubNode.getNodeValue().replace("&", "&amp;").replace("<", "&lt;"));
						}
					} else {
						innerXml.append(formatXmlNode(xmlSubNode, indentationLevel + 1));
					}
				}
			}

			final StringBuilder result = new StringBuilder();
			result.append(TextUtilities.repeatString("\t", indentationLevel));
			result.append("<");
			result.append(xmlNode.getNodeName());
			result.append(formatAttributes(xmlNode, indentationLevel));
			if (innerXml.length() == 0) {
				result.append(" />\n");
			} else {
				result.append(">\n");
				result.append(innerXml);
				result.append(TextUtilities.repeatString("\t", indentationLevel));
				result.append("</");
				result.append(xmlNode.getNodeName());
				result.append(">\n");
			}
			return result.toString();
		}
	}

	private static String formatAttributes(final Node xmlNode, final int indentationLevel) {
		final StringBuilder result = new StringBuilder();
		if (xmlNode.getAttributes() != null && xmlNode.getAttributes().getLength() > 0) {
			if (xmlNode.getAttributes().getLength() <= 5) {
				for (int attributeIndex = 0; attributeIndex < xmlNode.getAttributes().getLength(); attributeIndex++) {
					final Node attributeNode = xmlNode.getAttributes().item(attributeIndex);
					result.append(" ");
					result.append(attributeNode.getNodeName());
					result.append("=\"");
					result.append(attributeNode.getNodeValue().replaceAll("\"", "&quot;").replaceAll("<", "&lt;").replaceAll("&", "&amp;"));
					result.append("\"");
				}
			} else {
				result.append("\n");
				for (int attributeIndex = 0; attributeIndex < xmlNode.getAttributes().getLength(); attributeIndex++) {
					if (attributeIndex > 0) {
						result.append("\n");
					}
					final Node attributeNode = xmlNode.getAttributes().item(attributeIndex);
					result.append(TextUtilities.repeatString("\t", indentationLevel + 1));
					result.append(attributeNode.getNodeName());
					result.append("=\"");
					result.append(attributeNode.getNodeValue().replaceAll("\"", "&quot;").replaceAll("<", "&lt;").replaceAll("&", "&amp;"));
					result.append("\"");
				}
			}
		}
		return result.toString();
	}
}
